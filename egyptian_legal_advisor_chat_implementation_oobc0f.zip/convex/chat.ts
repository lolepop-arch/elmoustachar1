import { v } from "convex/values";
import { mutation, query, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import OpenAI from "openai";
import { api } from "./_generated/api";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

const SYSTEM_PROMPT = `أنت مساعد قانوني ذكي متخصص في القانون المصري فقط. يمكنك فهم الأسئلة حتى لو كانت تحتوي على أخطاء إملائية كبيرة. لا ترفض الإجابة بسبب الأخطاء في الكتابة، وقدم إجابة دقيقة وقانونية بما يتناسب مع القانون المصري. تأكد من أن الردود تكون واضحة ومفهومة بغض النظر عن الأخطاء الإملائية.

عليك أن:
١. تجيب دائماً باللغة العربية الفصحى المبسطة
٢. تحافظ على لغة مهنية ومحترمة
٣. تذكر المواد القانونية المتعلقة بالموضوع عند الإمكان
٤. تضيف في نهاية كل إجابة تنويهاً بأن هذه معلومات عامة وليست استشارة قانونية رسمية`;

export const sendMessage = mutation({
  args: { content: v.string() },
  handler: async (ctx, args): Promise<string> => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Store user's message
    await ctx.db.insert("messages", {
      userId,
      content: args.content,
      role: "user",
      createdAt: Date.now(),
    });

    // Get AI response
    const response: string = await ctx.scheduler.runAfter(0, api.chat.getAIResponse, {
      userId,
      userMessage: args.content,
    });

    return response;
  },
});

export const getAIResponse = action({
  args: { userId: v.id("users"), userMessage: v.string() },
  handler: async (ctx, args): Promise<string> => {
    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: args.userMessage }
      ],
    });

    const aiMessage = response.choices[0].message.content;
    if (!aiMessage) throw new Error("No response from AI");

    // Store AI response
    await ctx.runMutation(api.chat.storeAIResponse, {
      userId: args.userId,
      content: aiMessage,
    });

    return aiMessage;
  },
});

export const storeAIResponse = mutation({
  args: { userId: v.id("users"), content: v.string() },
  handler: async (ctx, args): Promise<void> => {
    await ctx.db.insert("messages", {
      userId: args.userId,
      content: args.content,
      role: "assistant",
      createdAt: Date.now(),
    });
  },
});

export const listMessages = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const messages = await ctx.db
      .query("messages")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("asc")
      .collect();

    return messages;
  },
});
