import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { useState } from "react";
import { Toaster } from "sonner";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col" dir="rtl">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-2xl font-bold text-emerald-700">المستشار المصري</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-3xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const messages = useQuery(api.chat.listMessages) || [];
  const sendMessage = useMutation(api.chat.sendMessage);
  const [newMessage, setNewMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || isLoading) return;

    setIsLoading(true);
    try {
      await sendMessage({ content: newMessage });
      setNewMessage("");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-emerald-700 mb-4">المستشار المصري</h1>
        <Authenticated>
          <div className="space-y-4">
            <p className="text-xl text-slate-600">مرحباً بك في خدمة الاستشارات القانونية</p>
            <p className="text-sm text-red-600">
              تنويه: هذه الخدمة تقدم معلومات عامة فقط ولا تعتبر استشارة قانونية رسمية. 
              يرجى استشارة محامٍ مؤهل للحصول على المشورة القانونية الرسمية.
            </p>
          </div>
        </Authenticated>
        <Unauthenticated>
          <p className="text-xl text-slate-600">سجل الدخول للبدء</p>
        </Unauthenticated>
      </div>

      <Unauthenticated>
        <SignInForm />
      </Unauthenticated>

      <Authenticated>
        <div className="flex flex-col gap-4">
          <div className="flex-1 space-y-4 p-4 border rounded-lg bg-gray-50 min-h-[400px] max-h-[600px] overflow-y-auto">
            {messages.map((message) => (
              <div
                key={message._id}
                className={`flex ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.role === "user"
                      ? "bg-emerald-500 text-white"
                      : "bg-white border border-gray-200"
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="اكتب سؤالك القانوني هنا..."
              className="flex-1 p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !newMessage.trim()}
              className="px-4 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 disabled:opacity-50"
            >
              {isLoading ? "جاري الإرسال..." : "إرسال"}
            </button>
          </form>
        </div>
      </Authenticated>
    </div>
  );
}
